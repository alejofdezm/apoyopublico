<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Lista de productos de la categoría <?php echo e($categoria->nombre); ?> </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                <?php if(Auth::User()->hasAnyRole(['admin'])): ?>
                <div class="row">
                    <a href="<?php echo e(route('crearproducto', $categoria->id)); ?>" class="btn btn-success" >Nuevo Producto</a>
                </div>
                <?php endif; ?>

                <div class="row">
                  <table class="table" data-form="deleteForm">

                  <thead class="thead-dark">

                    <tr>
                    <th>Acciones</th>
                    <th>id</th>                    
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    </tr>
                    </thead>
                    <?php $__currentLoopData = $listaproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>  
                            <td>
                            <div class="row">                                
                                <div class="col-4">
                                    <a href="<?php echo e(route('editarproducto', $productos->id)); ?>" class="btn btn-info" >Editar</a>
                                </div>

                                <div class="col-4">
                                <?php if(Auth::User()->hasAnyRole(['admin'])): ?>
                                    <?php echo Form::model($productos, ['method' => 'delete', 'route' => ['eliminarproductos', $productos->id], 'class' =>'form-inline form-delete']); ?>

                                        <?php echo Form::hidden('id', $productos->id); ?>

                                        <?php echo Form::submit(trans('Eliminar'), ['class' => 'btn btn-danger delete', 'name' => 'delete_modal']); ?>

                                    <?php echo Form::close(); ?>  
                                <?php endif; ?>
                                </div>
                            </div>                                
                            </td> 
                            <td>
                                <?php echo e($productos->id); ?>

                            </td>                         
                           
                            <td>
                                <?php echo e($productos->nombre); ?>

                            </td>
                            <td>
                                <?php echo e($productos->descripcion); ?>

                            </td>
                            <td>
                                <?php echo e($productos->precio); ?>

                            </td>
                   
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   

                  </table>

                  <?php echo e($listaproductos->links()); ?>

                  
                  </div>
                </div>
            </div>
        </div>
    </div> 
</div>


<?php echo $__env->make('modal.eliminar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/eliminar.js')); ?>"></script>
<?php $__env->stopSection(); ?>



 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/productos/lista.blade.php ENDPATH**/ ?>