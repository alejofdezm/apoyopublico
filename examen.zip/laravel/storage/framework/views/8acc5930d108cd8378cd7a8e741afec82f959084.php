<div class="modal" id="confirm" tabindex="-1" role="dialog">
        <div class="modal-dialog"  role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Confirmar eliminación</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                    
                </div>
                <div class="modal-body">
                    <p>Esta seguro que desea eliminar el registro?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" id="delete-btn">Eliminar</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">cerrar</button>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\laravel\resources\views/modal/eliminar.blade.php ENDPATH**/ ?>