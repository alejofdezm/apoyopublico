<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
           
            <div class="card">
                <div class="card-header">Lista de productos de la categoría</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                
                    <?php if(Auth::User()->hasAnyRole(['admin'])): ?>
                    <div class="row">
                        <a href="#" class="btn btn-success" >Nuevo Producto</a>
                    </div>
                    <?php endif; ?> 
                    <div class="row">
                        <div class="col-12">
                            <center> ---------------- </center>
                        </div>
                    </div>
                    <div class="row">
                    <?php echo e($listadeproductos->links()); ?>

                    </div>
                        <div class="row">
                            <?php $__currentLoopData = $listadeproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="col-4">
                                       <div class="card">
                                            <img src="<?php echo e($producto->nombreimagen == ''? route('verimagen','default.jpg'): route('verimagen',$producto->nombreimagen)); ?> " 
                                                    alt="Imagen por defecto" class="card-img-top">
                                            <div class="card-body">
                                                <div class="card-title">
                                                <div class="row">
                                                <div class="col-6">
                                                
                                                </div>
                                                <div class="col-6">
                                                        <div class="btn btn-danger">
                                                            <?php echo e($producto->precio); ?>

                                                        </div>
                                                </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <b> <?php echo e($producto->nombre); ?> </b>
                                                    </div>                                                
                                                </div>                                                
                                                </div>
                                                <p> <?php echo e($producto->descripcion); ?></p>
                                                <div class="card-footer">
                                                    <?php echo e($producto->categoria()->first() == null ? 'Sin categoría' : $producto->categoria()->first()->nombre); ?>

                                                </div>
                                            </div>     
                                       </div>
                               </div> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <div class="row">
                    <?php echo e($listadeproductos->links()); ?>

                    </div>
                </div>
        </div> 
    </div>
</div>
 
<?php $__env->stopSection(); ?>
 



 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/productos/todoslosproducto.blade.php ENDPATH**/ ?>