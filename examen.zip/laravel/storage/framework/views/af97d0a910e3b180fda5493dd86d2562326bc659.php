<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Crear producto en la categoria: <?php echo e($categoria->nombre); ?> </div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                  
                    <form method="POST" action="<?php echo e(route('guardarnuevoproducto')); ?>">
                       
                        <?php echo csrf_field(); ?>

                        <input type="hidden" name="idcategoria" value="<?php echo e($categoria->id); ?>">

                        <div class="form-group row">
                        
                        <label for="nombre" class="col-md-4 col-form-label text-md-right">Nombre</label>							

                            <div class="col-md-6">
                                     
                            <input id="nombre" name="nombre" type="text" 
                                        class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" 
                                        value="<?php echo e(old('nombre')); ?>" required autofocus>


                                <?php if($errors->has('nombre')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>


                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="descripcion" class="col-md-4 col-form-label text-md-right">Descripción</label>									
                            <div class="col-md-6">
                               
                                <input id="descripcion" name="descripcion" type="text"   
                                        class="form-control<?php echo e($errors->has('descripcion') ? ' is-invalid' : ''); ?>" 
                                        value="<?php echo e(old('descripcion')); ?>" >


                                <?php if($errors->has('descripcion')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                        </div>

                        
                        <div class="form-group row">
                            <label for="precio" class="col-md-4 col-form-label text-md-right">Precio</label>									
                            <div class="col-md-6">
                               
                                <input id="precio" name="precio" type="number" step="any"  
                                        class="form-control<?php echo e($errors->has('precio') ? ' is-invalid' : ''); ?>" 
                                        value="<?php echo e(old('precio')); ?>" 
                                >


                                <?php if($errors->has('precio')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('precio')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                        </div>
                        <div class="form-group row mb-0">
                            <div class="col-6 text-center">
                                <button type="submit" class="btn btn-success">
                                   Guardar
                                </button>
                            </div>
                            <div class="col-6  text-center">
                                    
                                    <a class="btn btn-danger " 
                                       href="<?php echo e(route('listarcategorias')); ?>" 
                                       role="button">Regresar</a>

                                </div>
                        </div>

                    </form>

                </div>
            </div>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/productos/crear.blade.php ENDPATH**/ ?>