<?php

use Illuminate\Database\Seeder;

use App\Categoriaproductos;
use App\Productos;

class CategoriasproductoTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        for($i = 1; $i <= 10; $i++)
            {
                $categoria = new Categoriaproductos();
                $categoria->nombre ="Categoria #" . $i;
                $categoria->descripcion =" Descripcion de la categoria #" . $i;
                $categoria->save(); 

                    for($j = 1; $j <= 20; $j++)
                    {
                        $producto = new Productos();
                        $producto->idcategoriaproductos = $categoria->id;
                        $producto->nombre ="Producto #". $i . "-" . $j ;
                        $producto->descripcion =" Descripcion de la Producto #" . $i . "-" . $j;
                        $producto->precio = ((($j * 80)  + ($i + 1)) +  5000);
                        $producto->save();
                    }
            } 
    }
}
