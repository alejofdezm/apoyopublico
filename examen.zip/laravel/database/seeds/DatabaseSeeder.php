<?php

use Illuminate\Database\Seeder;

use App\User;
use App\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(RoleTableSeeder::class);

        $role_user = Role::where('name', 'user')->first();
        $role_admin = Role::where('name', 'admin')->first();

        $user = new User();
        $user->name = 'Admin System';
        $user->email = 'admin@domain.com';
        $user->password = bcrypt('admin123'); 
        $user->save();
        $user->roles()->attach($role_admin);

        $user1 = new User();
        $user1->name = 'User Universidad';
        $user1->email = 'user@domain.com';
        $user1->password = bcrypt('user123'); 
        $user1->save();
        $user1->roles()->attach($role_user);

        $this->call(CategoriasproductoTableSeeder::class);
    }
}
