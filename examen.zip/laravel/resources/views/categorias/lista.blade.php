@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Categorias</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                
                @if(Auth::User()->hasAnyRole(['admin']))
                <div class="row">
                    <a href="{{ route('crearcategoria') }}" class="btn btn-success" >Nueva Categoría</a>
                </div>
                @endif

                <div class="row">
                  <table class="table" data-form="deleteForm">

                  <thead class="thead-dark">

                    <tr>
                    <th>Acciones</th>
                    <th>id</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    </tr>
                    </thead>
                    @foreach($listacategoria as $categoria )
                    <tr>  
                            <td>
                            <div class="row">
                                <div class="col-4">
                                    <a href="{{ route('listadeproductos', $categoria->id) }}" class="btn btn-secondary" >Ver productos</a>
                                </div>

                                <div class="col-4">
                                    <a href="{{ route('editarcategoria', $categoria->id) }}" class="btn btn-info" >Editar</a>
                                </div>

                                <div class="col-4">
                                @if(Auth::User()->hasAnyRole(['admin']))

                                {!! Form::model($categoria, ['method' => 'delete', 'route' => ['eliminarcategoria', $categoria->id], 'class' =>'form-inline form-delete']) !!}
                                    {!! Form::hidden('id', $categoria->id) !!}
                                    {!! Form::submit(trans('Eliminar'), ['class' => 'btn btn-danger delete', 'name' => 'delete_modal']) !!}
                                {!! Form::close() !!}   
                                @endif

                                </div>
                            </div>                                
                            </td>                 
                            
                            <td>
                                {{$categoria->id}}
                            </td>
                            <td>
                                {{$categoria->nombre}}
                            </td>
                            <td>
                                 {{$categoria->descripcion}}
                            </td>
                   
                    </tr>
                    @endforeach                   

                  </table>

                  {{ $listacategoria->links()}}
                  </div>
                </div>
            </div>
        </div>
    </div> 
</div>


@include('modal.eliminar')

@endsection

@section('script')
    <script src="{{ asset('js/eliminar.js')}}"></script>
@endsection



 