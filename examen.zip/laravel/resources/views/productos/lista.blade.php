@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Lista de productos de la categoría {{ $categoria->nombre }} </div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                
                @if(Auth::User()->hasAnyRole(['admin']))
                <div class="row">
                    <a href="{{ route('crearproducto', $categoria->id) }}" class="btn btn-success" >Nuevo Producto</a>
                </div>
                @endif

                <div class="row">
                  <table class="table" data-form="deleteForm">

                  <thead class="thead-dark">

                    <tr>
                    <th>Acciones</th>
                    <th>id</th>                    
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    </tr>
                    </thead>
                    @foreach($listaproductos as $productos )
                    <tr>  
                            <td>
                            <div class="row">                                
                                <div class="col-4">
                                    <a href="{{ route('editarproducto', $productos->id) }}" class="btn btn-info" >Editar</a>
                                </div>

                                <div class="col-4">
                                @if(Auth::User()->hasAnyRole(['admin']))
                                    {!! Form::model($productos, ['method' => 'delete', 'route' => ['eliminarproductos', $productos->id], 'class' =>'form-inline form-delete']) !!}
                                        {!! Form::hidden('id', $productos->id) !!}
                                        {!! Form::submit(trans('Eliminar'), ['class' => 'btn btn-danger delete', 'name' => 'delete_modal']) !!}
                                    {!! Form::close() !!}  
                                @endif
                                </div>
                            </div>                                
                            </td> 
                            <td>
                                {{ $productos->id }}
                            </td>                         
                           
                            <td>
                                {{ $productos->nombre }}
                            </td>
                            <td>
                                {{ $productos->descripcion }}
                            </td>
                            <td>
                                {{ $productos->precio }}
                            </td>
                   
                    </tr>
                    @endforeach                   

                  </table>

                  {{ $listaproductos->links()}}
                  
                  </div>
                </div>
            </div>
        </div>
    </div> 
</div>


@include('modal.eliminar')

@endsection

@section('script')
    <script src="{{ asset('js/eliminar.js')}}"></script>
@endsection



 