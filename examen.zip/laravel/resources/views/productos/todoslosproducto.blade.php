@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
           
            <div class="card">
                <div class="card-header">Lista de productos de la categoría</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                
                    @if(Auth::User()->hasAnyRole(['admin']))
                    <div class="row">
                        <a href="#" class="btn btn-success" >Nuevo Producto</a>
                    </div>
                    @endif 
                    <div class="row">
                        <div class="col-12">
                            <center> ---------------- </center>
                        </div>
                    </div>
                    <div class="row">
                    {{ $listadeproductos->links() }}
                    </div>
                        <div class="row">
                            @foreach($listadeproductos as $producto)
                               <div class="col-4">
                                       <div class="card">
                                            <img src="{{ $producto->nombreimagen == ''? route('verimagen','default.jpg'): route('verimagen',$producto->nombreimagen) }} " 
                                                    alt="Imagen por defecto" class="card-img-top">
                                            <div class="card-body">
                                                <div class="card-title">
                                                <div class="row">
                                                <div class="col-6">
                                                
                                                </div>
                                                <div class="col-6">
                                                        <div class="btn btn-danger">
                                                            {{$producto->precio}}
                                                        </div>
                                                </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12">
                                                        <b> {{ $producto->nombre }} </b>
                                                    </div>                                                
                                                </div>                                                
                                                </div>
                                                <p> {{ $producto->descripcion }}</p>
                                                <div class="card-footer">
                                                    {{ $producto->categoria()->first() == null ? 'Sin categoría' : $producto->categoria()->first()->nombre }}
                                                </div>
                                            </div>     
                                       </div>
                               </div> 
                            @endforeach
                        </div>
                    <div class="row">
                    {{ $listadeproductos->links() }}
                    </div>
                </div>
        </div> 
    </div>
</div>
 
@endsection
 



 