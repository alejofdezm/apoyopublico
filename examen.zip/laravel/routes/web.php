<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//aquí va todo lo de categoria
Route::get('/categorias/lista', 'CategoriaController@listarcategorias')->name('listarcategorias');

Route::get('/categorias/crear', 'CategoriaController@crear')->name('crearcategoria');

Route::post('/categorias/guardar/nuevo', 'CategoriaController@guardarnuevacategoria')->name('guardarnuevacategoria');

Route::get('/categorias/editar/{id}', 'CategoriaController@editar')->name('editarcategoria');

Route::put('/categorias/guardar/edicion/{id}', 'CategoriaController@guardaredicioncategoria')->name('guardaredicioncategoria');

Route::delete('/categorias/eliminar/{id}', 'CategoriaController@eliminar')->name('eliminarcategoria');

//aquí va todo lo de producto
Route::get('/productos/categoria/{id}','ProductoController@obtenerproducto')->name('listadeproductos');

Route::delete('/productos/eliminar/{id}', 'ProductoController@eliminar')->name('eliminarproductos');

Route::get('/produtos/editar/{id}', 'ProductoController@editar')->name('editarproducto');

Route::put('/productos/guardar/edicion/{id}', 'ProductoController@guardaredicionproducto')->name('guardaredicionproducto');

Route::get('/produtos/crear/{idcategoria}', 'ProductoController@crear')->name('crearproducto');

Route::post('/productos/guardar/nuevo', 'ProductoController@guararnuevoproducto')->name('guardarnuevoproducto');

Route::get('/lista/productos', 'ProductoController@listartodoslosproductos')->name('listadeproductosv2');

Route::get('/storage/{nombreimagen}', 'ProductoController@obtenerimagen')->name('verimagen');





