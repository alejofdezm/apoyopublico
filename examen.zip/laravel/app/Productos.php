<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productos extends Model
{
    protected $primaryKey = 'id'; 
    protected $table = 'productos';    
   
    public function categoria(){

        return $this->belongsTo('App\Categoriaproductos', 'idcategoriaproductos', 'id');
    }

}
