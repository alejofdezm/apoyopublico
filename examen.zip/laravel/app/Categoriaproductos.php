<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoriaproductos extends Model
{
    protected $primaryKey = 'id'; 
    protected $table = 'categoriaproductos';
    
    protected $fillable = ['nombre', 'descripcion'];

}
