<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Categoriaproductos;
use App\Productos;

class CategoriaController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function listarcategorias(Request $request)
    {
        $request->user()->authorizeRoles(['user', 'admin']);  

        $listacategias = Categoriaproductos::paginate(6);

        return view('categorias.lista',['listacategoria' => $listacategias]); 

    } 

    public function eliminar(Request $request, $id ){

         $request->user()->authorizeRoles('admin');  

         $datosAEditar = Categoriaproductos::where('id', $id)->first();
         if($datosAEditar != null)
            $datosAEditar->delete();
         
         return redirect(route('listarcategorias'));
                  
    }

    public function editar(Request $request, $id ){
        
        $request->user()->authorizeRoles(['user', 'admin']); 

        $datosAEditar = Categoriaproductos::where('id', $id)->first();         
      
        return view('categorias.editar', ['datos' => $datosAEditar]);
    }

    private function actualizarcategoriadb(array $datosFormulario, $id)
    {
        $datosAEditar = Categoriaproductos::where('id', $id)->first();    

        $datosAEditar->nombre = $datosFormulario['nombre'];
        $datosAEditar->descripcion = $datosFormulario['descripcion'];

        $datosAEditar->save();
    }

    public function guardaredicioncategoria(Request $request, $id)
    {
        $request->user()->authorizeRoles(['user', 'admin']); 
        
        $datodelformulario = $request->all();  

        $ejecutar = $this->crearreglasdevalidacion($datodelformulario);

        $ejecutar->validate();
        
        $this->actualizarcategoriadb($datodelformulario, $id);

        return redirect(route('listarcategorias'));

    }

    public function crear(Request $request)
    {
        $request->user()->authorizeRoles('admin');  

        return view('categorias.crear');
    } 


    private function crearreglasdevalidacion(array $datosavalidar)
    {        
        return Validator::make($datosavalidar,
                                [
                                  'nombre' => 'required|string|max:35',  
                                  'descripcion' => 'string|min:10|max:120'  
                                ]
                                );
    }

    private function gudarDatosdb(array $datosAGuardar){
		  
        $modeloagregar = [
            'nombre' => $datosAGuardar['nombre'],
            'descripcion' => $datosAGuardar['descripcion']
        ]; 

        $categoria = Categoriaproductos::create($modeloagregar); 

        return $categoria; 
    } 


    public function guardarnuevacategoria(Request $request){

        $request->user()->authorizeRoles('admin');  

        $datodelformulario = $request->all();           

        $ejecutar = $this->crearreglasdevalidacion($datodelformulario);

        $ejecutar->validate();

        $datosdelmodeloguardado = $this->gudarDatosdb(  $datodelformulario  );

        return redirect(route('listarcategorias'));

    }
}
