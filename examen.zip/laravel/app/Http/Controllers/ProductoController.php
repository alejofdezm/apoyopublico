<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use App\Categoriaproductos;
use App\Productos;

class ProductoController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }  

    public function listartodoslosproductos(Request $request){

        $request->user()->authorizeRoles(['user', 'admin']); 
        $listadeproductos = Productos::paginate(21); 
        return view('productos.todoslosproducto',['listadeproductos' => $listadeproductos]);
    }  
    
    //aqui vamos a poner lo de producto

    public function obtenerproducto(Request $request, $id){

        $request->user()->authorizeRoles(['user', 'admin']); 

        $productosDelaCategoria = Productos::where('idcategoriaproductos', $id )->paginate(10);        

        $categoria = Categoriaproductos::where('id' , $id)->first();
        
        return view('productos.lista',['listaproductos' => $productosDelaCategoria,
                                        'categoria' => $categoria ]);
    }


    public function eliminar(Request $request, $id ){

        $request->user()->authorizeRoles('admin');  
        $datosAEditar = Productos::where('id', $id)->first();      

        $idcategoria = -1;

            if($datosAEditar != null){
                $idcategoria = $datosAEditar->idcategoriaproductos;
                $datosAEditar->delete();
            }   

        return redirect(route('listadeproductos', $idcategoria));                 
   }

   public function editar(Request $request, $id ){
        
        $request->user()->authorizeRoles(['user', 'admin']); 

        $datosAEditar = Productos::where('id', $id)->first();         
        
        $listadecategorias = Categoriaproductos::get();

        return view('productos.editar', ['datos' => $datosAEditar, 
                                         'listadecategorias' => $listadecategorias]);
    }


    public function crear(Request $request, $idcategoria ){
        
        $request->user()->authorizeRoles(['user', 'admin']); 
        
        $categoria = Categoriaproductos::where('id' , $idcategoria)->first();

        return view('productos.crear', ['categoria' => $categoria]);
    }

    
    private function crearreglasdevalidacion(array $datosavalidar)
    {        
        return Validator::make($datosavalidar,
                                [
                                  'nombre' => 'required|string|max:35',  
                                  'descripcion' => 'string|min:10|max:120',  
                                  'precio' => 'numeric|min:0',
                                  'idcategoria' => 'numeric|min:0', 
                                ]
                                );
    }
    
    private function actualizarproductosdb(array $datosFormulario, $id, $nombrecompletodeimagen)
    {
        $datosAEditar = Productos::where('id', $id)->first();    

        $datosAEditar->nombre = $datosFormulario['nombre'];
        $datosAEditar->descripcion = $datosFormulario['descripcion'];
        $datosAEditar->precio = $datosFormulario['precio'];
        $datosAEditar->idcategoriaproductos = $datosFormulario['idcategoria'];
        $datosAEditar->nombreimagen = $nombrecompletodeimagen;

        $datosAEditar->save();

        return $datosAEditar;
    }

    public function guardaredicionproducto(Request $request, $id)
    {
        $request->user()->authorizeRoles(['user', 'admin']); 
        
        $datodelformulario = $request->all();  
       
        $ejecutar = $this->crearreglasdevalidacion($datodelformulario);        
        $ejecutar->validate();


        $nombrecompleto = '';

        if(isset($datodelformulario['nombreimagen']))
        {          
            Validator::make($datodelformulario,['nombreimagen' => 'mimes:jpeg,jpg,png'])->validate();

            $archivo = $request->file('nombreimagen');
            $nombrecompleto = $archivo->getClientOriginalName();

            $nombre = pathinfo($nombrecompleto, PATHINFO_FILENAME);
            $extension = pathinfo($nombrecompleto, PATHINFO_EXTENSION);
            
            $nombrecompleto = $nombre.'-'.$id.'.'. $extension;       

            \Storage::disk('public')->put($nombrecompleto, \File::get($archivo));
        }      
         
        $datosActualizado = $this->actualizarproductosdb($datodelformulario, $id, $nombrecompleto);
        
        return redirect(route('editarproducto', $datosActualizado->id));     

    }

    private function crearproductodb(array $datosFormulario)
    {
        $nuevoProducto = new Productos();

        $nuevoProducto->nombre = $datosFormulario['nombre'];
        $nuevoProducto->descripcion = $datosFormulario['descripcion'];
        $nuevoProducto->precio = $datosFormulario['precio'];
        $nuevoProducto->idcategoriaproductos = $datosFormulario['idcategoria'];

        $nuevoProducto->save();

        return $nuevoProducto;
    }
    public function guararnuevoproducto(Request $request)
    {
        $request->user()->authorizeRoles(['admin']); 
        
        $datodelformulario = $request->all();  
        
        $ejecutar = $this->crearreglasdevalidacion($datodelformulario);

        $ejecutar->validate();
        
        $nuevoproductoguardado = $this->crearproductodb($datodelformulario);

        return redirect(route('listadeproductos', $nuevoproductoguardado->idcategoriaproductos ));  
    }
    
    public function obtenerimagen(Request $request, $nombreimagen)
    {        
        $public_path = public_path();
        $url = $public_path.'/storage/'.$nombreimagen;
        
        if(\Storage::exists($nombreimagen)){
            return response()->download($url);
        }

        abort(404);
    }
    
}
